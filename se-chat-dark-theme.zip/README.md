# StackExchange Chat Dark Theme (plus!)

## rlemon fork

restyled Olivers original and added a bunch of JS "features".   
  
![](http://i.imgur.com/xxMPtoI.png)

Only tested in Chrome. FireFox is on the roadmap. IE is smelly and will not get support. 

Available for Chrome here: https://chrome.google.com/webstore/detail/so-dark-chat-%20/bbkjccfnenmgidehjhaabamobpbaaghh  