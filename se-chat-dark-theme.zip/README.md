# StackExchange Chat Dark Theme (plus!)

## rlemon fork v0.0.1.8

restyled Olivers original and added a bunch of JS "features".   
  
Only tested in Chrome. FireFox is on the roadmap. IE is smelly and will not get support. 

Available for Chrome here: https://chrome.google.com/webstore/detail/so-dark-chat-%20/bbkjccfnenmgidehjhaabamobpbaaghh  

*Note: updates will not always be current in the online version. watch for version number changes*